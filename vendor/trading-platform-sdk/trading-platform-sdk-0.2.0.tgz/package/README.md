# @trading-platform/sdk

Contract-first SDK facade over the trading-platform research contracts (017–031). Module authors and
research agents work against a typed, documented public surface — without reaching into platform
internals (`src/research/**`, `src/storage/**`, `src/canonical/**`, the MCP gateway server, …).

It is **not** a new runner, gateway, strategy format, or module DSL — it is a stable facade over the
existing contracts.

## Install

The SDK is a **standalone** package — it has no dependency on the `trading-platform` repo and needs no
workspace link, sibling checkout, or overrides. Declare it like any normal dependency:

```jsonc
// consumer package.json — from a private registry / npm package
{ "dependencies": { "@trading-platform/sdk": "<version>" } }
```

For local verification, install a packed tarball directly:

```bash
npm install /path/to/trading-platform-sdk-<version>.tgz
```

External consumers **must not** depend on the `trading-platform` root package and **must not** use
`workspace:` / `link:` / `overrides` to resolve the SDK — it installs cleanly on its own.

`@modelcontextprotocol/sdk` is an **optional peer** — only needed if you use the reference transport
(`@trading-platform/sdk/agent/mcp-transport`).

## Public import surface

Four subpaths. Consumer-facing code imports by package name; never reach into platform internals.

### `@trading-platform/sdk` (root)

- Constants: `CONTRACT_VERSION` (`'017.2'`), `SUPPORTED_CONTRACT_VERSIONS` (`['017.1','017.2']`),
  `SUPPORTED_MARKET_DATA_KINDS`, `SDK_VERSION`, `SDK_CAPABILITIES` (all flags `false`).
- Types: `MarketDataKind`, `MarketDataCoverageState`, `SdkCapabilityDescriptor`.

### `@trading-platform/sdk/builder` — author + validate modules

- Helpers: `createManifest`, `createOverlayManifest`, `dataNeeds`, `capabilities`, `assembleBundle`,
  `preflightValidate`, `strategyDecision`, `overlayDecision`, `templates`, `buildSdkMeta`.
- Re-exports the full 017/020/023/030 contract surface (types + constants) — e.g. `ModuleManifest`,
  `StrategyModule`, `HypothesisOverlayModule`, `StrategyDecision`, `OverlayDecision`,
  `DataNeedsDeclaration`, `CapabilityDeclaration`, `ValidationResult`, `ValidationCode`.
- Helper types: `StrategyManifestInput`, `OverlayManifestInput`, `PackageInput`, `PackagedBundle`,
  `ValidateAuthoringInput`, `AuthoringValidationResult`, `ModuleTemplate`, `TemplateId`, `SdkMeta`,
  `BundleDescriptor`, `ModuleBundle`, `SandboxValidationCode`.
#### Validation boundary (lightweight local vs. authoritative gateway)

`preflightValidate` runs **lightweight, standalone** checks only — manifest shape, required fields,
declaration validity (contract version ∈ supported, no forbidden capabilities), and bundle layout
(`manifest.json`/`bundle.json` present, `entryPoint` + `bundleHash` present). It executes nothing,
runs no sandbox/validation engine, and imports no platform package. Issue codes are a subset of the
contract taxonomy (no new taxonomy).

**Authoritative** full validation — sandbox import-scan, runtime isolation, and running a hypothesis
through the runner — happens only on the **`trading-platform` / hosted gateway**, reached via
`@trading-platform/sdk/agent` (the 031 `validate_module` / `submit_run` tools). The standalone SDK
deliberately does not duplicate sandbox semantics: use `preflightValidate` for fast local authoring
feedback, then submit to the gateway for the authoritative verdict.

### `@trading-platform/sdk/agent` — research workflow over MCP 031 (transport-agnostic core)

- Transport: `GatewayTransport` (consumer-supplied), `GatewayToolName`, `GATEWAY_TOOL_NAMES` (8 tools).
- Workflow: `discover`, `listDatasets`, `validateModule`, `submitRun`, `getRunStatus`, `getRunResult`,
  `cancelRun`, `readArtifactPage`, `awaitCompletion` (polling fallback), `readArtifactPages`
  (bounded async iterator — there is **no** full-raw artifact read API).
- Coverage: `coverageByKind`, `isUsable`, `isMissing`, `isStale`, `isUnsupported`, `isPresentZero`
  (present-zero ≠ missing).
- Errors / outcome: `GATEWAY_ERROR_CATEGORIES` (6), `TERMINAL_STATUSES` (5), `NON_TERMINAL_STATUSES`,
  `classifyError`, `classifyOutcome`, `isTerminal`.
- DTOs: own-declared, structurally equivalent to the platform gateway DTOs (verified by a conformance
  gate) — `ControlledRunRequest`, `RunJobHandle`, `RunStatusView`, `RunResultSummary`,
  `CoverageEntryDTO`, `ArtifactReference`, `ReadArtifactRequest`, `ArtifactPage`, `GatewayError`, …

### `@trading-platform/sdk/agent/mcp-transport` — reference transport (opt-in subpath)

- `createMcpTransport(client)` → `GatewayTransport` over an MCP client (`McpClientLike`, matching
  `@modelcontextprotocol/sdk`'s `Client.callTool`). Part of the package but **the core never imports
  it**; opt-in. Owns no credentials, starts no gateway, opens no live/execution/ingestion capability.

## Quick example

```ts
import { createManifest, dataNeeds, assembleBundle, preflightValidate } from '@trading-platform/sdk/builder';
import { discover, submitRun, awaitCompletion, getRunResult, readArtifactPages } from '@trading-platform/sdk/agent';
import { createMcpTransport } from '@trading-platform/sdk/agent/mcp-transport';
```

See [`specs/032-trading-platform-sdk/quickstart.md`](../../specs/032-trading-platform-sdk/quickstart.md)
for the full author + agent walkthrough.

## Boundaries (what the SDK does NOT do)

- No exchange credentials, no live orders, no execution authority.
- No ingestion; no direct raw Parquet/DuckDB reads. funding/taker only via the 030 research contract.
- No internal platform filesystem paths in the public `.d.ts`.
- Submitted modules stay untrusted — execution remains sandbox-owned (019).
- Raw artifacts are read bounded/paged only (no full-raw read API).
- `CONTRACT_VERSION` stays `017.2`; no new market-data kinds / CanonicalRow fields / strategy DSL.

## Build & verify (platform developer)

The SDK is **standalone**: it vendors a generated snapshot of the platform contract surface and has
no dependency on the platform package. There is no workspace link to wire.

```bash
# platform — source of truth (npm)
npm ci && npm run build

# SDK — regenerate the vendored snapshot, build standalone, run the full gate suite
npm run gen:sdk-snapshot           # vendor the public contract snapshot from the platform source-of-truth
npm run build:sdk                  # compile the standalone SDK (no platform dependency)
npm run check:034                  # build + snapshot drift-check + build:sdk + pgates(017…032 + 034), EXIT=0
```

> The vendored snapshot under `packages/sdk/src/{contract,builder/_vendor}` is generated, not hand-
> edited. If the platform contracts change, the drift gate (`verify_034_snapshot_drift`) fails and
> asks you to re-run `npm run gen:sdk-snapshot` — drift is caught in this repo, never in a consumer.
